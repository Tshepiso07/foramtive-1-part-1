/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part1chatapp;

/**
 *
 * @author tshep
 */

public class MainApp {
    {    
import java.util.Scanner;
    
    

    public static void main(String[] args) {
        {
        // Scanner allows the user to enter information
       Scanner input = new Scanner(System.in);
       
       // Create an object of the login class so we can call its methods
       Login login = new Login();
    }

    //--- REGISTRATION SECTION ---
    System.out.println("=== USER REGISTRATION ===")
    
             String username = "";
        boolean userOk= false;
        while (!userOk)
        {
    System.out.print("Enter a username: "); 
    String username = input.nextLine();
    
     if (login.checkUserName(username)) 
            {
                System.out.println("Username successful");
                userOk = true;
            } 
            else 
            {
                System.out.println("Username is not correctly formatted; please "
                        + "ensure that your username contains an underscore and "
                        + "is no more than five characters in length.");
            }
        }
        
        String password = "";
        boolean passOk = false;
        while (!passOk) 
        {
    
    System.out.print("Enter a password: ");
     String password = input.nextLine();
     
     if (login.checkPasswordComplexity(password)) 
            {
                System.out.println("Password successfully captured");
                passOk = true;
            } 
            else 
            {
                System.out.println("Password is not correctly formatted; please "
                        + "ensure that the password contains at least eight "
                        + "characters, a capital letter, a number, and a special character.");
            }
        }
        
          String phone = "";
        boolean phoneOk = false;
        while (!phoneOk) 
        {
     
    System.out.print("Enter your South African phone number(+27...):");
    String phone = input.nextLine();
    
    if (login.checkPhoneNumber(phone)) 
            {
                System.out.println("Phone number correct");
                phoneOk = true;
            } 
            else 
            {
                System.out.println("Cell phone number incorrectly formatted or "
                        + "does not contain international code.");
            }
        }

    
    //Call the registerUser method and store the message it returns
    String response = Login.registerUsers(username, password, phone);
    
    //Show the registration message
    System.out.println(response);
    

    //--- LOGIN SECTION ---
    if (response.equals("User registered successfully.")) 
    {
    System.out.println("\n=== USER LOGIN ===");
    boolean loggedIn = false;

            while (!loggedIn)
            {
    System.out.print("Enter your username; ");
    String loginUsername = input.nextLine();
    
    System.out.print("Enter your password");
    String loginPassword = input.nextLine();
    
    //call loginUser to check if Details match the stored ones
    boolean LoggedIn = login.loginUser(loginUsername, loginPassword);
    
    //Print out the correct login message
    String loginMessage = login.returnLoginstatus(LoggedIn)
    System.out.println(loginMessage);
            }
          }   
        }   
      }   
    }
   }

