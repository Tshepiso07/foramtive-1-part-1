/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part1chatapp;

/**
 *
 * @author tshep
 */
public class Login {
    
    /*
    Declaring user login variables
    */
    String Username;
    String Password;
    String phoneNumber;
    
public boolean checkUserName(String username){
    
        username.contains("_") && username.length() <=5;
    }
        
public boolean checkPasswordcomplexity(string password)  {      
    boolean hasCapital = false;
    boolean HasNumber = false;
    boolean hasSpecial = false;
    
    for (int i = 0; i < Password.length(); i++) {
        char c = password.charAt(i);

        if (Character.isUpperCase(c)) {
            hasCapital = true;
        } else if (character.isDigit(c)) {
            hasNumber = true;
        } else if (!Character.isLetterOrDigit(c)) {
            hasSPecial = true; 
        }
    }   

    return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
    
}
public boolean checkCellPhoneNumber(String phone) {
     return phone.startsWith("+27")&& phone.length() <= 12;
}

public boolean loginUsesr(String username,String password) {
     return this.Username.equals(username)&& this.Password.equals(password);
}

public String returnLoginStatus(boolean success) {
    if(success) {
       return "Welcome " + username + +-"it is great to see you again";
    } else {
        return "Username or password incorrect, please try again.";
    }
}